-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2429090)
addappid(2429091,0,"8b7df642bcd3fd54e96a583749bf69a6992eb46e089c9e92c1085a8e072fd2b6")
setManifestid(2429091,"233642052253206486")