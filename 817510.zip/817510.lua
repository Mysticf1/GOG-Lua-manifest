-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(817510)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(817511,0,"7c4a9c962da81133091bdc3ccd85cc1f2f4bf57878608b321854f5abf25c9596")
setManifestid(817511,"3566446063466044282")
addappid(817514,0,"1259a7743d30abb5672192c30b33fcc9ce3f73ae47bc1ff3184e1c40619a2647")
setManifestid(817514,"2542668944123975233")
addappid(817512,0,"fca3888a6fc2aea4873b71580e5f413f6d517f51683cd43e9495963202921c75")
setManifestid(817512,"9046154978398151682")
addappid(817513,0,"bdd50a5cb3c2bee54f6a82787e85f83abf60785b15e7b98528bca6a086ab6069")
setManifestid(817513,"5764478757933747838")