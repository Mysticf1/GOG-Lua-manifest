-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1355440)
addappid(1355441,0,"0d4785f8046840801307c846aecbd0da8d74a73735f5946bbdd47c8bd6677094")
setManifestid(1355441,"7468982065604962033")