-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1542110)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1542111,0,"04321ff9f2ae8d71864cf09a7457b535d2514ea68a6f40bb96e1490d49d37294")
setManifestid(1542111,"9213648742977140790")