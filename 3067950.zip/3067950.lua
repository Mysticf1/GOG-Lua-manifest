-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3067950)
addappid(3067951,0,"a010f40fb7ca2da5dcd250b854776a9611de8cd499466ae772a13c748c23137b")
setManifestid(3067951,"2408823832259147953")