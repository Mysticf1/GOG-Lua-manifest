-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1328890)
addappid(229000)
setManifestid(229000,"4622705914179893434")
addappid(1328891,0,"5d1f123be0b908623a2423c1af74ee4486879ffaf17e3fd29d6edd56aa6b778a")
setManifestid(1328891,"1268842205037269841")
addappid(1328892,0,"01572888dba8edfac2e294c5e070b7ce87facd5a6a2dbb4b3dc8eee33cb398c3")
setManifestid(1328892,"499857923904420649")
addappid(1328893,0,"59bf142d7a1c97a30596ceb1909e5b37d9c54ff836192a6a69fe1816361ef2ac")
setManifestid(1328893,"7884324552909284946")