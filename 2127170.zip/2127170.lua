-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2127170)
addappid(2127171,0,"075150f759b90293a468cc8f42b5a8a712c0d9585a79699240bc97d8ade3c794")
setManifestid(2127171,"4926568959439436697")