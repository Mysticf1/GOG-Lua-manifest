-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(347560)
addappid(228982)
setManifestid(228982,"6413394087650432851")
addappid(347561,0,"cec2163648e5764993cc34554281852029ae1ee835329c3d70d640ea410affcb")
setManifestid(347561,"144840992624570780")
addappid(347562)