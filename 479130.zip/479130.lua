-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(479130)
addappid(479131,0,"a8eee97a1d7676c8d01da7f00c50d1387bbb7e5cee0ee426a8a043de139f3b98")
setManifestid(479131,"2313042897969777474")