-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1399700)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1399701,0,"23b4755c45fb37d72a93d30b3af5dd32c3e956054dafb0efc3193312aa03e90d")
setManifestid(1399701,"7227459322745306342")
addappid(1399702,0,"45857885427ab2419000ac3ada753d4df7afdfc5d46f90820ba468bb1be7b1f3")
setManifestid(1399702,"2188266609300690901")
addappid(1399703,0,"54ec35d8a02a4442a7399b502be48c01ae9ae4b7f2ca1fbe9b479b29240f6b28")
setManifestid(1399703,"6404600599423043444")