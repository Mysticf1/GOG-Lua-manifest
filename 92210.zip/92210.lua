-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(92210)
addappid(92211,0,"a8055bac9460421273eb7f9c964c8d269d2b8dd7c0a2f3f73a8a2a8316ba43bf")
setManifestid(92211,"5430351920771966121")
addappid(92212,0,"80653d94d14f2361b353a1fdf03a2cc86d2bea70c7f72b42098b03eee7ece4fd")
setManifestid(92212,"2703709907049199323")
addappid(92213,0,"4cefffa3205ef8b702dc91b829b76b0ac110f9447c2cff21b23ae947f5703581")
setManifestid(92213,"4299878351848929786")
addappid(92214,0,"c393d30d17c7871ca61e5c03f5e4f2326d3464b15f6ecf519fb2618f82ce3189")
setManifestid(92214,"2377229228418731185")
addappid(92215,0,"d1a137273088d380169efd2fe230e7373ebe1696713b25e240c980b23b7f8511")
setManifestid(92215,"8641176445263109388")
addappid(92216,0,"819814c0c24069cb344e00fb8faf81ad5888721340b22a4b4350b0f232149d96")
setManifestid(92216,"1512657805895685478")
addappid(92217)
addappid(92218)