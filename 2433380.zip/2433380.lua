-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2433380)
addappid(2433381,0,"15a4d89ad3ecc1cd7364d0fb2a9b4b129f88bdd8e79753682219612273a97394")
setManifestid(2433381,"6440874418991823963")