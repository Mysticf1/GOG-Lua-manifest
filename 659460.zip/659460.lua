-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(659460)
addappid(659461,0,"6a71dc1585fd682f1172dc10b97bca32bfb54fc024fb88f23f83a96cc59fb8b7")
setManifestid(659461,"8407242550815762145")