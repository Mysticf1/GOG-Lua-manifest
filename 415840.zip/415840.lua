-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(415840)
addappid(415841,0,"03fd4d44b66f2307ee165275492ab1e21e063de6c443dae2ff6e3bd7b016e0e2")
setManifestid(415841,"6960585157312254023")
addappid(415842,0,"ed421c9a1784050705c28dc521c250b78a9a9124ee71d1b9c66245ee8c1d3896")
setManifestid(415842,"8027950364817048491")
addappid(415843,0,"2db1be892cf4532a558e5496211527626efa2c872ce3b13cde2fa190263711da")
setManifestid(415843,"3084896062254438160")