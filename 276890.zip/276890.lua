-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(276890)
addappid(276891,0,"9d14c038aef01c7a7edda41cf4303b31838df8ec5a7162660e9d292e6221c594")
setManifestid(276891,"1816038023522433417")