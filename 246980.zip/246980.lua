-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(246980)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(229000)
setManifestid(229000,"4622705914179893434")
addappid(246982,0,"5b295610f8b682ce5c0c52b5662caea5e93fb43a065d7f28a4b9e43a03131303")
setManifestid(246982,"5574135960212955721")
addappid(246981)
addappid(278720)