-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3209910)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(3209911,0,"5dad293b039482fa23aa075f9e3e61be3a227bd2093badd6ec5c9132fd0b448d")
setManifestid(3209911,"7579203854966219370")