-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1741220)
addappid(1741221,0,"c7d16272c894d1d730916e7d2d4bac330304e6a85b9e12ca7bd93e0a0d2ae188")
setManifestid(1741221,"8319167205811854112")