-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2846290)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2846291,0,"3b6089658a4300ded7def75bba0bd6d6bd77f1b4b188203ed59822d29efd7f73")
setManifestid(2846291,"5973728050599881207")
addappid(2846292)