-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1605010)
addappid(1605011,0,"31c697c603b788a58dbde8d588021460335682e315438a3a06e3d32e2324be4d")
setManifestid(1605011,"7811241974028811180")
addappid(1605090,0,"26e67814e7bc04932ba7d75342626bac9d5e2acb230ea44c6df454f3ddf27633")
setManifestid(1605090,"2301614803102286918")