-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(380970)
addappid(380971,0,"696d6b8798709b4c0e9bc903d15fe9a38f0af3b01c0b8c674504fc77761e16bd")
setManifestid(380971,"4391497591031555952")