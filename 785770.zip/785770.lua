-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(785770)
addappid(785771,0,"2c7097ddbc5e503a653700238917cebd42e5cb34f1bd54118c32df3457f45516")
setManifestid(785771,"4938289512580637578")