-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2089120)
addappid(2089121,0,"4e450465cf81ded146da70ffaf79dec1b0d500a4237673bd6d374acea1adc069")
setManifestid(2089121,"174025085575166554")