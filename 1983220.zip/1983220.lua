-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1983220)
addappid(1983221,0,"88e6e701ee0361e8de509461f96a050abab2e00671402d937acd8f0d4ed82988")
setManifestid(1983221,"8194623747687614089")