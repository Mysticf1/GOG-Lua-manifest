-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2589170)
addappid(2589171,0,"57e6f4be1e53b3222d6be7b715fb74225f0205ae7499053a9a440b77b60623ac")
setManifestid(2589171,"5736604344618663819")