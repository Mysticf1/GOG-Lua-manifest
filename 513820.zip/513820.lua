-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(513820)
addappid(513821,0,"ce2ead7175ddae7e4d811213a96e1244c9a4c9916c04a7d5ad02f1cc20802e00")
setManifestid(513821,"501594165426884461")
addappid(513822,0,"d23d41a06cfbb92c678c1a006a835d1d719cb9f38c915a01bc5cd5338d7623a5")
setManifestid(513822,"3888265847266695505")
addappid(513823,0,"00f9614e684e174e94a65394a3528286def3d6da0de4b0238969316325d18da9")
setManifestid(513823,"4201764112466537916")