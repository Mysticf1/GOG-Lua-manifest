-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(657120)
addappid(657121,0,"828c43d49ccaf84b4704abd12b567d24b4ba51c373c927edf35ef35fa338167c")
setManifestid(657121,"945186717318957766")
addappid(657122)
addappid(657123)