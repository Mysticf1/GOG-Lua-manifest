-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1793250)
addappid(1793251,0,"6244e3fb605c1830a37e6e6429cad51f5fca42e3562976c02fd0d45f944dbef9")
setManifestid(1793251,"7095267399912461386")
addappid(1793252)
addappid(1793253)