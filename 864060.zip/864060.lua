-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(864060)
addappid(864061,0,"7e5b3a61958199f381f8dd0323098a9360d2622fc002baeafe238d5d205262d8")
setManifestid(864061,"2294188841444864000")
addappid(864062,0,"49b54dba7468c3fa06641fb4fe301005ee360a17a234f8fc16ecfd27056d8af1")
setManifestid(864062,"2881935341657707729")
addappid(864063)
addappid(864064)
addappid(864065,0,"eef9d77cbcec801f3bf52f04480cce278f9ce9e4c81e3ac7b0643af7643ad5cc")
setManifestid(864065,"4191097990415986531")