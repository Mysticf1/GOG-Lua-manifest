-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1802710)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(1802711,0,"efefa2a23c0112e13a7cd3198cd6120833afacadc276fda80874af59c1af0504")
addappid(1802712,0,"08d634f951ebc26371df13ec1e57280541c63f9818fefe7e4f82784d57a2d830")
addappid(1802713)