-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1566880)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1566881,0,"425a65e84dd99521033eb9d137b3e41b95b6d26f823d1f8227dbb3a6d4bc0572")
setManifestid(1566881,"4457274844766180864")
addappid(1566882)
addappid(2389110,0,"87e61effb3dbf81dedeff59048a1ae93023bf8fe1d6e0f7cce88eb56c1242c84")
setManifestid(2389110,"927096750600495170")
addappid(2296844,0,"6e12c7a8446ad8cd625cf9d6a52b8cb326182af8a6f1e868e4e14f68652c001b")
setManifestid(2296844,"7835852827236308400")