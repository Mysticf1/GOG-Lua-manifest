-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1408260)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(1408261,0,"89f4b00450507b7d8ef88b3426737758edd3256182ac10209249b2e31809ccfa")
setManifestid(1408261,"6586992010774531359")