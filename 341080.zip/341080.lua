-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(341080)
addappid(341081,0,"40f4c960176e2450b7b7fac99ffa72981911b8d1366983096df488a4ad25df24")
setManifestid(341081,"2973589263853863029")