-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(259170)
addappid(228981)
setManifestid(228981,"7613356809904826842")
addappid(259171,0,"36a625c3c671f93e981314833d0250232a6ff453cd9f7f626e94425c2f7f731a")
setManifestid(259171,"2952440167262994037")