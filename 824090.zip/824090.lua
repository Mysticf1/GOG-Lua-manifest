-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(824090)
addappid(824091,0,"06bd9463f0fa05613dcbc00d5e8cbc36ea99d04267f98be930a86af5d9a1813a")
setManifestid(824091,"9123292242741948795")