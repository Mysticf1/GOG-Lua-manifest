-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1343130)
addappid(1343131,0,"0edab97b5de0106627b7e7205af46830e0a55bbb7a4e8320de301301fe1579bf")
setManifestid(1343131,"5870544989574705659")
addappid(1343132,0,"a86cbafc7b679cc86f920938f0a3a67cc129cab492011391ac3997aee399e8b0")
setManifestid(1343132,"1704386224726741060")