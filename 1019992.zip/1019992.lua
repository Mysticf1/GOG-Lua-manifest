-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1019992)
addappid(1019992,0,"ab543be4da40040c398b2870c79ba30a1a6c60c9fd30ce81895f8a86e1a66fdd")
setManifestid(1019992,"7124423404804439736")