-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1752150)
addappid(1752151,0,"e7457b45d49ceed90e3ac11f5c7850a80b60494b73ed5177dd13858753a35ab1")
setManifestid(1752151,"7016139405366438505")