-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3320)
addappid(3321,0,"26234aa7a8ed8885d4b33589933cc80eb2791003f63b325e8b7aa7b5b81af115")
setManifestid(3321,"4977529675831131285")
addappid(3323,0,"cedbdc0297b63f8916b4040931443823f486b5bd224ae00583ea38c871049f2d")
setManifestid(3323,"1535218128431827631")
addappid(3324,0,"0ab82fcd718a9462618aaf3bc33c0c7376d101bc69fef4d8478cd14fdf2319fd")
setManifestid(3324,"6211021125429645920")
addappid(3325,0,"4133100689e8ddfbaed547829631e786ce9ad11434b1800d613a05116368bc35")
setManifestid(3325,"7564886100134026446")
addappid(3326,0,"493d55f9dfa8ea06975a94646cb892a4a8649706db69c933b5bb64a89654b046")
setManifestid(3326,"2110114037744774308")