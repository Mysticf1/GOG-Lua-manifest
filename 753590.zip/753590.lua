-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(753590)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(753591,0,"96f72b2e7b96ebdc347602ef2a8bb3a25e4730d8b4b5714476c630895760f90a")
setManifestid(753591,"8681915770002770383")
addappid(1461510,0,"13a8ef767b3ddba5da9023195abe2650179f51f4b228ee380044c11945fdb893")
setManifestid(1461510,"9039521845598328877")