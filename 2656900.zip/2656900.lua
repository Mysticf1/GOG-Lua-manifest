-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2656900)
addappid(2656901,0,"921738a70b83afc5221d128ae75e6dea8c9d8f1fe8d54b2ec249cd4336037766")
setManifestid(2656901,"4623413285039115691")
addappid(2677270,0,"bce111fa7b87444e2626b3e663ee1516f2d3a5a88ee00e71c1b467a32b96378a")
setManifestid(2677270,"8225721654484046502")