-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1243880)
addappid(1243881,0,"9c76c46b4e15c982e34a35e5fcad6928f0edd9f79bfc5bd39c1fc18d4e70b35d")
setManifestid(1243881,"8093436897792844604")