-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1478860)
addappid(1478861,0,"3f3f834476a9ab7f0d54adae83d3c9bde5dd5e301ba3a4d1daa6c7a8df12850f")
setManifestid(1478861,"1008342107564833734")