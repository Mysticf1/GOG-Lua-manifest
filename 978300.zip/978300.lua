-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(978300)
addappid(228988)
setManifestid(228988,"6645201662696499616")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(978301,0,"65f739287b59d3fd8ff9ec51fcac70962d4c92e140c89af3f6e397df4ab92e45")
setManifestid(978301,"2323925017821319416")