-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(458480)
addappid(458481,0,"a5c5ac380f028e91910db772c344aa831bd492dce8f52f7962468c05c79a7fb7")
setManifestid(458481,"6138916336581150279")
addappid(458482,0,"70a2a20ae843051a25f9624fa1e183506847bdcf68fe8b332e7c0344714327b2")
setManifestid(458482,"5981229649187655554")
addappid(458483,0,"e9aaaf8365506f78cc51bd8264df15f6c9b6a5919c341395d34b94bdac29dd45")
setManifestid(458483,"6116259687367164433")