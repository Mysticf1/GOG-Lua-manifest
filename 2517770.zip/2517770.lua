-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2517770)
addappid(2517771,0,"5ceea076063863fea3dd88e2e5610e729ee6ceb7971b513c5f85204a114d9c6c")
setManifestid(2517771,"7405179634765012596")
addappid(2517772)