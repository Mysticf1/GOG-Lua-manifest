-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2091500)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(2091501,0,"4e845660c7eeae140561f31c279fb36b625f9c0277bda568e4a729dc867f16c3")
setManifestid(2091501,"8997824064011326882")