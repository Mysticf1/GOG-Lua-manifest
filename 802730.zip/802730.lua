-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(802730)
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(802731,0,"3f82306c6b07cf4b84fccdb1bb7d95b2b1f0904b89f77bd909538c72dc04e51b")
setManifestid(802731,"8793845163688532252")