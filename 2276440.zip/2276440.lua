-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2276440)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(2276441,0,"666f16ca1dd0c34bf6659cca548d2214ef2ecb8523ee2e2864446354363de3d5")
setManifestid(2276441,"2275618559019301991")