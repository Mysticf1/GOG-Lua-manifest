-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3051470)
addtoken(3051470,4950010657296042549)
addappid(3051471,0,"fd82a12824aaa017fd9f9df79a69c912499fcb6030c97006df6481e8eecd7432")
setManifestid(3051471,"2484691943971470103")