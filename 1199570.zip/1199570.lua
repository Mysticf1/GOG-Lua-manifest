-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1199570)
addappid(1199571,0,"8b9f6d075afc6a44d97fc3b785d129d865993de7b6cab9519cc59b2fb08397d3")
setManifestid(1199571,"8826355242728735547")