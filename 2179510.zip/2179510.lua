-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2179510)
addappid(2179511,0,"1e9ee0385c05968c29f694bbd3650a298322d98ce365adf7fcc07068f00e65f6")
setManifestid(2179511,"5096624605628380968")