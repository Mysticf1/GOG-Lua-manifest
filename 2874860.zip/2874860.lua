-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2874860)
addappid(2874861,0,"25d36ab96cad74a9b15e8a2b11e41b25dae55276e82bc7adc27156ddecfc206a")
setManifestid(2874861,"8238198225934367510")