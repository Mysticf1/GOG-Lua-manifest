-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1326330)
addappid(1326331,0,"f32a2a1444b718eefaa00c025a749505ef94f3620b38836df66bea547ed96d4c")
setManifestid(1326331,"2131818080902032111")