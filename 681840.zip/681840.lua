-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(681840)
addtoken(681840,604255079983624957)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(681841,0,"e5269c363e95663043e9527c513c883f00d22dc91ce50db9d81f39d2f0d86275")
setManifestid(681841,"4320062490263980394")