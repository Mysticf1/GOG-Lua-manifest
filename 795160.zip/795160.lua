-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(795160)
addappid(982130,0,"00c100c2e30c702fdd3a25c95ef61bd5142ad0cf14ff82a0c7aa2bb7d74c37ae")
setManifestid(982130,"3489118329869122500")
addappid(795161,0,"0dd7b0d4abf36532f19cfd6098c7ede796aa0f590f46a61cba5fab3449e485b1")
setManifestid(795161,"3012322068696118383")
addappid(795162,0,"d59dd911b097d935daa8ced247eebeef32d3da48511d1cdd9ae2c156a083c506")
setManifestid(795162,"2119013552468229832")