-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1431040)
addappid(1431041,0,"3350334fa99fbf83316b13484562a4bb3f7c60dded4b976f0144a7203d9d4929")
setManifestid(1431041,"6543281496989629025")