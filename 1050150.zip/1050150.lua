-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1050150)
addappid(1050151,0,"5b2dd8357d660009b5bdd2567e9e9a84e77d1e840f36ada02bb7579c6279b02a")
setManifestid(1050151,"868322775694116041")