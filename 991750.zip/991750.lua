-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(991750)
addappid(991751,0,"0a356d8c08c10903d4a5db43c38cd2648dc693b8c56a6e352f5346324a5569ef")
setManifestid(991751,"1015834607459863409")
addappid(1039720)
addappid(991752)