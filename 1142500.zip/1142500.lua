-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1142500)
addappid(1142501,0,"60995328e213db5589ccebb9c28fccca223395e7bcdd58881555d1c28de66a8e")
setManifestid(1142501,"4336186160119915508")
addappid(1142502,0,"8ae29460936da602bb6348b2bd021640a608e8bc0eb6f0c4e5cf356cd12231f1")
setManifestid(1142502,"6864400149720791007")