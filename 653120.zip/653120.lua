-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(653120)
addappid(228985)
setManifestid(228985,"3966345552745568756")
addappid(228986)
setManifestid(228986,"8782296191957114623")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(653121,0,"6a5816966b34887bf6ea53aad7ecd0599d6504e04920d14cce32f689084c2323")
setManifestid(653121,"2435595151501815516")
addappid(653122)
addappid(653123,0,"5fee795c96de2fb8fc5d1a41559d03b12170199b764a74c2eacd547f9b97bc3d")
setManifestid(653123,"1085803682714976338")
addappid(653124,0,"b47da34616a1f443feba6e1b961f7706cd11d2e5a91f3c72bc1ddee0d17fa429")
setManifestid(653124,"2676474854407790928")