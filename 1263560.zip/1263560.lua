-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1263560)
addappid(1263561,0,"39b739399985c9f172d3cf760cc656a5204265d6d379bf57fa7d0649f045b1df")
setManifestid(1263561,"9126476251421814680")
addappid(1263562,0,"bb76ead756d8679d3eac6d906a309d513157345478c0f0b6a61535489d101546")
setManifestid(1263562,"7598365427120725875")