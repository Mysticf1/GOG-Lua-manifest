-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1352940)
addappid(1352941,0,"1063828d86ffdb4cf46cb84ae05e307133f477dea5a4c6cc705d3349fc0816a2")
setManifestid(1352941,"7642155612632903143")
addappid(1352942,0,"6deaa2456a35de8b9764482b4c1d0e0602365de10de573284496a150b7ae7a6a")
setManifestid(1352942,"4260234255309339092")
addappid(1352943,0,"24776940f3538a0bc69312f1390859f28d506a3d9c10c8fecb05453cfa563454")
setManifestid(1352943,"1993110520964219543")
addappid(1352944,0,"bf4110eb3a7330973633c55ca43a2f83111f6bde8384ef41c6c64db3c22afd9f")
setManifestid(1352944,"3388695102387321498")