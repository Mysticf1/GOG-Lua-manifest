-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1504250)
addappid(1504251,0,"f5d2af9c3726eeb9e48fe9859bb745685d8d22289eca2516d0c6eb6fec179e69")
setManifestid(1504251,"557569815749670686")