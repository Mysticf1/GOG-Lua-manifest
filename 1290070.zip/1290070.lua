-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1290070)
addappid(1290071,0,"e5847d1f92c6a1eefab8a83f625d1f91ed86ed5c4c569fb7d87d15c23e0ebdb5")
setManifestid(1290071,"538555339753596299")
addappid(1319450,0,"b7282022b0eec4e9cb916cc16500249619029bcd304ffce0c4b510dd129c5c76")
setManifestid(1319450,"8985213206125001569")