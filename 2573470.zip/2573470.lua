-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(2573470)
addappid(2573471,0,"3fbb3e9384fc79669ade05ebf6d42d97726b85411bc9cff7870fe25a8a95e549")
setManifestid(2573471,"125548122364714277")