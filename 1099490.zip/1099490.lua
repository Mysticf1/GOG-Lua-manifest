-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(1099490)
addappid(1099491,0,"0c1ac5bc0719711084e5b47433e5e32ec80843ed44dd5ca4a6ee522bd96b6099")
setManifestid(1099491,"3741237480894698370")