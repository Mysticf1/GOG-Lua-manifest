-- This file was fetched from twentytwo cloud which is the exclusive property of Twentytwo server.
-- Redistribution of twentytwo's files is not allowed AT ALL
-- Join the server here: https://discord.com/invite/vwGWeTFTXW

addappid(3563950)
addappid(228989)
setManifestid(228989,"550968249685141759")
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(3563951,0,"d79c72cb1aeac2590f28b6c0c23a7f4ee64d94f89e67c5e97898ac84150e8b25")
setManifestid(3563951,"571320856170924133")